	<!-- SECTION -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<div class="col-md-12">
					<div class="section-row">
						<div class="section-title">
							<h2 class="title">Disclaimer</h2>
						</div>
                            <p style="text-align: justify;">E-news adalah sebuah media blog yang mengulas topik seputar bisnis secara umum, pemasaran online, media sosial, teknologi, kewirausahaan, inspirasi dan motivasi, dan beberapa topik terkait lainnya. Artikel pada website ini ditulis oleh beberapa orang penulis dan kontributor yang memiliki minat dan passion yang berbeda-beda sehingga konten website ini akan berbeda-beda sesuai dengan kategorinya.</p>
                            <p style="text-align: justify;">Dengan adanya beberapa kategori pada blog ini, kami berharap dapat membantu pembaca dalam memberikan informasi yang akurat dan bisa dipercaya. Beberapa artikel yang dimuat di http://e-news.muhammad-rizal.com/ berasal dari sumber lain.</p>
                            <p style="text-align: justify;">Salah satu topik yang ditulis di blog ini adalah tentang teknologi. Saat ini internet sudah membuka kesempatan besar bagi setiap orang untuk berkreasi, dan menciptakan inovasi dalam dunia marketing dan menghasilkan uang. Bisnis online bisa memberikan penghasilan yang tidak terbatas, mulai dari penghasilan ratusan ribu rupiah, puluhan juta rupiah, ratusan juta rupiah, hingga miliaran rupiah per bulan. Semua tergantung pengetahuan, niat, dan tekad yang mengerjakannya.</p>
                            <p style="text-align: justify;">http://e-news.muhammad-rizal.com/ akan terus berkembang dan berusaha memberikan informasi-informasi yang mudah-mudahan bermanfaat bagi para pembaca. Kami juga menerima masukan dan kritik membangun dari para pembaca sehingga kami bisa membenahi kekurangan yang ada. Silahkan kirimkan masukan dan kritik Anda melalui halaman kontak.</p>
                            <p style="text-align: justify;">Akhir kata dari saya, salam sukses buat Anda dan semoga website sederhana ini memberikan inspirasi dan informasi yang bermanfaat bagi para pembaca.</p><br>
                            <p>Salam</p><br><br>
                            <p><strong>Muhammad Rizal</strong></p>
					</div>
				</div>
			</div>
		</div>
	</div>