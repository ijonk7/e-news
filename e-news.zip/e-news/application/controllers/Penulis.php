<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Penulis extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Penulis_model', '', TRUE);
	}

	public function index()
	{
		// Code: Login With Facebook
		if (! $this->session->userdata('sudah_login')) {
			$this->session->set_userdata('url_saat_ini', current_url());

			$fb = new Facebook\Facebook([
			  'app_id' => '522555908558801', // Replace {app-id} with your app id
			  'app_secret' => 'e038bc6bcb111c0499d80cab460efccb',
			  'default_graph_version' => 'v2.2',
			  ]);
			
			$helper = $fb->getRedirectLoginHelper();
				
			$permissions = ['email']; // Optional permissions
			$loginUrl = $helper->getLoginUrl('https://e-news.muhammad-rizal.com/login_fb', $permissions);
		}
		// End Code: Login With Facebook

		$total_artikel = $this->Penulis_model->total_artikel();
		$artikel_penulis = $this->Penulis_model->artikel_penulis();
            
		$data['judul_halaman'] = 'Penulis';
        $data['menu'] = '';       
		$data['single_page'] = '';
		$data['main_content'] = 'penulis/penulis';

		$this->load->view('template', compact('data', 'total_artikel', 'artikel_penulis', 'loginUrl'));
	}
}
