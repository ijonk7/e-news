<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pencarian extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Pencarian_model', '', TRUE);
	}

	public function cari()
	{
        if ($_GET) {
            // Code: Login With Facebook
            if (! $this->session->userdata('sudah_login')) {
                $this->session->set_userdata('url_saat_ini', current_url());
    
                $fb = new Facebook\Facebook([
                  'app_id' => '522555908558801', // Replace {app-id} with your app id
                  'app_secret' => 'e038bc6bcb111c0499d80cab460efccb',
                  'default_graph_version' => 'v2.2',
                  ]);
                
                $helper = $fb->getRedirectLoginHelper();
                    
                $permissions = ['email']; // Optional permissions
                $loginUrl = $helper->getLoginUrl('https://e-news.muhammad-rizal.com/login_fb', $permissions);
            }
            // End Code: Login With Facebook
    
            $input = (object) $this->input->get(null, true);     

            $hasil_pencarian = $this->Pencarian_model->pencarian($input);
            $total_artikel = $this->Pencarian_model->total_artikel();

            $data['judul_halaman'] = 'Hasil Pencarian';
            $data['menu'] = ''; 
            $data['single_page'] = '';
            $data['pencarian'] = $input->kata_kunci;
            $data['main_content'] = 'pencarian/pencarian';
    
            $this->load->view('template', compact('data', 'total_artikel', 'hasil_pencarian', 'loginUrl'));
        }
    }
}
